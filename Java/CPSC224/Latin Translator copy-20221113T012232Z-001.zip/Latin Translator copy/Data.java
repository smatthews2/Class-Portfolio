public class Data {
    
    public int myValue = 0;


    

}
