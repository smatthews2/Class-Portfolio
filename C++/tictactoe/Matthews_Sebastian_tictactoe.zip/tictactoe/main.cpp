
#include <iostream>
using namespace std;

void print2dElements(const char inArray[3][3], int rows, int cols);

int main(){
    char gameBoard[3][3] = {{'-','-','-'},{'-','-','-'},{'-','-','-'}};
    int userRow, userCol;
    print2dElements(gameBoard, 3, 3);
    cout << "Player's turn. State the row where you would like your X to be.\n";
    cin >> userRow;
    cout << "Now, state the column were you would like your X to be.\n";
    cin >> userCol;
    gameBoard[userRow][userCol] = 'X';
    print2dElements(gameBoard, 3, 3);
    return 0;
}

void print2dElements(const char inArray[3][3], int rows, int cols){
    for (int i = 0; i < rows; i++){
        for (int j = 0; j < cols; j++){
            cout << inArray[i][j] << ' ';
        }
        cout << endl;
    }
    cout << endl;
}